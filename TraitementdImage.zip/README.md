# Traitement d'Image
De la couleur au noir et blanc

* [Voir le pdf élève](https://github.com/raoulhatterer/TraitementdImage/blob/master/TraitementdImage.pdf)
* [Voir le html élève](http://htmlpreview.github.io/?https://github.com/raoulhatterer/TraitementdImage/blob/master/TraitementdImage.html)


* [Voir le pdf professeur](https://github.com/raoulhatterer/TraitementdImage/blob/master/TraitementdImageProf.pdf)
* [Voir le html professeur](http://htmlpreview.github.io/?https://github.com/raoulhatterer/TraitementdImage/blob/master/TraitementdImageProf.html)


